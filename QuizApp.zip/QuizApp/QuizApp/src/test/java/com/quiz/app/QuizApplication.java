package com.quiz.app;

public class QuizApplication {
}
